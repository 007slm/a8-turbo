package io.nats.demo;



import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.util.function.Consumer;

@Component

public class LoggingListener {

    @Bean
    public Consumer<Object> onDataChangeMessage() {
        return message -> {
            System.out.println("## Received message: " + message);
        };
    }
}
